<?php

include('db.php');

if(isset($_POST['submit']))
{
	$data = $_POST['data'];
	echo $data;
  
}


?>





<!DOCTYPE html>
<html>
<head>
	<title>Input form With Dropdown</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<h4 class="text-center" style="font-weight: bold">Dropdown Form</h4>
			</div>
			<div class="col-md-6 col-md-offset-3">
				<form method="post" action="" class="form-horizontal">
					<div class="form-group">
						<label for="sell" class="control-label col-sm-3">Category List</label>
						<div class="col-sm-9">
							<select class="form-control" id="sell" name="data">
								<?php
								    $get_data = "SELECT * FROM category";
								    $run_data = mysqli_query($con,$get_data);

								    while($row = mysqli_fetch_array($run_data))
								    {
								    	$cat_name = $row['cat_name'];
								    	$id = $row['id'];
								    	echo "
								    	   <option value=$id>$cat_name</option>

								    	";

								    }
								?>
							     
                                
							
						    </select>
						</div>
					</div>
					<div class="col-md-12 text-center">
						<input type="submit" name="submit" value="Submit" class="btn btn-primary">
					</div>
					
				</form>
			</div>
		</div>
	</div>

</body>
</html>